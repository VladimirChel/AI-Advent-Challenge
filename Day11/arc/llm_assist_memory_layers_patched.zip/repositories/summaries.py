from __future__ import annotations

from dataclasses import dataclass
from datetime import timezone

from db import get_db_connection
from llm.schemas import ChatMessage


@dataclass
class ConversationSummaryRecord:
    conversation_id: str
    branch_id: str
    summary: str
    source_upto_seq_no: int
    updated_at: str | None = None


def get_conversation_summary(conversation_id: str, branch_id: str) -> ConversationSummaryRecord | None:
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT conversation_id, branch_id, summary, source_upto_seq_no, updated_at
                FROM conversation_summaries
                WHERE conversation_id = %s AND branch_id = %s
                """,
                (conversation_id, branch_id),
            )
            row = cur.fetchone()

    if not row:
        return None

    return ConversationSummaryRecord(
        conversation_id=row[0],
        branch_id=row[1],
        summary=row[2],
        source_upto_seq_no=int(row[3]),
        updated_at=row[4].replace(tzinfo=timezone.utc).isoformat() if row[4] else None,
    )


def build_summary_from_messages(messages: list[ChatMessage], *, max_items: int = 10, max_chars: int = 4000) -> str:
    if not messages:
        return ""

    compact: list[str] = []
    for msg in messages[-max_items:]:
        role = "Пользователь" if msg.role == "user" else "Ассистент" if msg.role == "assistant" else "Система"
        content = " ".join(msg.content.split())
        compact.append(f"{role}: {content[:400]}")

    summary = "Краткая сводка последних важных сообщений:\n" + "\n".join(f"- {line}" for line in compact)
    return summary[:max_chars]


def upsert_conversation_summary(
    conversation_id: str,
    branch_id: str,
    summary: str,
    source_upto_seq_no: int,
) -> None:
    with get_db_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO conversation_summaries (
                    conversation_id, branch_id, summary, source_upto_seq_no, updated_at
                )
                VALUES (%s, %s, %s, %s, NOW())
                ON CONFLICT (conversation_id, branch_id)
                DO UPDATE SET
                    summary = EXCLUDED.summary,
                    source_upto_seq_no = EXCLUDED.source_upto_seq_no,
                    updated_at = NOW()
                """,
                (conversation_id, branch_id, summary, source_upto_seq_no),
            )
        conn.commit()
