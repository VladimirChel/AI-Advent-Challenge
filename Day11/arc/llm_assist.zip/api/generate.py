import time
import uuid
from fastapi import APIRouter, HTTPException

from llm.schemas import GenerateRequest, GenerateResponse, ChatMessage
from llm.client import call_chat_completion, extract_text_from_chat_completion, get_usage
from repositories.messages import save_messages

router = APIRouter()


@router.post("/generate", response_model=GenerateResponse)
def generate(payload: GenerateRequest) -> GenerateResponse:
    request_id = str(uuid.uuid4())
    started = time.perf_counter()

    conversation_id = payload.conversation_id or str(uuid.uuid4())
    branch_id = payload.branch_id or "main"

    # 🔹 пока без памяти — просто передаём вход
    response = call_chat_completion(
        model=payload.model,
        messages=payload.messages,
        temperature=payload.temperature,
        max_tokens=payload.max_tokens,
        top_p=payload.top_p,
        presence_penalty=payload.presence_penalty,
        frequency_penalty=payload.frequency_penalty,
        user_id=payload.user_id,
    )

    content, finish_reason = extract_text_from_chat_completion(response)

    if not content.strip():
        raise HTTPException(status_code=502, detail="empty_model_response")

    usage = get_usage(response)

    # 🔹 сохраняем диалог
    save_messages(
        conversation_id=conversation_id,
        branch_id=branch_id,
        user_id=payload.user_id,
        model=payload.model,
        messages=[
            *payload.messages,
            ChatMessage(role="assistant", content=content),
        ],
    )

    latency_ms = int((time.perf_counter() - started) * 1000)

    return GenerateResponse(
        request_id=request_id,
        conversation_id=conversation_id,
        branch_id=branch_id,
        task_id=payload.task_id,
        model=payload.model,
        content=content,
        finish_reason=finish_reason,
        usage=usage,
        latency_ms=latency_ms,
    )